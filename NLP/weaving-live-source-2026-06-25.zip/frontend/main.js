/* Material Encounters — capture + projection window (/display).
 *
 * This is the single live window: it records the room (browser Web Speech API,
 * or the server-mic fallback), streams recognized text to the server, and draws
 * the broadcast concept map — captured phrases clustering toward the seed themes
 * around 'creativity'. It auto-zooms to whichever theme is under discussion and
 * draws the curated graph (nodes + connections authored on /presentation) on top.
 *
 * Keyboard-driven, no on-screen controls:
 *   Space — record / pause      F — fullscreen      C — clear (new session)
 *
 * The same map is broadcast to every read-only viewer (/ and /live). ML runs on
 * the server in the background.
 */

(() => {
  "use strict";

  const canvas = document.getElementById("map");
  const ctx = canvas.getContext("2d");
  const _params = new URLSearchParams(location.search);

  const recIndicator = document.getElementById("rec-indicator");
  const recLabel = document.getElementById("rec-label");

  // Projected display visuals: captured phrases are quiet dots in overview and
  // become readable labels when their theme is zoomed.
  const DISPLAY = true;
  // Labels are upright (horizontal) by default for a wall projection. For a
  // ceiling/table projection, ?radial=1 rotates each label's top toward centre.
  const RADIAL_LABELS = _params.get("radial") === "1";

  // id -> node (see makeNode). nx/ny are current normalized coords in [-1, 1].
  const nodes = new Map();
  let edges = [];
  // Live co-occurrence threads between main theme nodes (overview only).
  let themeEdges = [];
  let numAnchors = 0;
  let micOn = false;
  let focusId = null; // id of the node we're zoomed into, or null

  // Auto-zoom: follow the theme currently under discussion, then zoom back out
  // after a quiet stretch. Driven by the per-utterance theme tag from the server.
  const AUTO_ZOOM_HOLD_MS = 20000;
  let autoThemeIndex = null;
  let autoThemeAt = 0;
  let lastUtteranceKey = null;
  // When zoomed into a theme, reveal at most this many of its strongest phrases.
  const DISPLAY_THEME_MAX = 14;
  let displayThemeIds = null;
  let displayThemeSlots = null;
  let displayThemeCount = 0;

  let socket = null;
  let dpr = window.devicePixelRatio || 1;
  let width = 0;
  let height = 0;
  let time = 0;

  // Camera zoom (animated): 1 in overview, larger when focused.
  let zoom = 1;
  const FOCUS_ZOOM = 1.7;
  let camOffsetX = 0;

  // No pointer interaction on the projection; these keep drawNodes() generic.
  const press = null;
  const hoverId = null;

  const RING_RADIUS = 0.62;

  // ---- Layout / sizing --------------------------------------------------
  function resize() {
    dpr = window.devicePixelRatio || 1;
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = Math.floor(width * dpr);
    canvas.height = Math.floor(height * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  window.addEventListener("resize", resize);
  resize();

  function scale() {
    return Math.min(width, height) * 0.5 * 0.82 * zoom;
  }
  function project(nx, ny) {
    return [width / 2 + camOffsetX + nx * scale(), height / 2 + ny * scale()];
  }

  // ---- Anchored positioning ---------------------------------------------
  function anchorDefault(index) {
    if (index <= 0) return [0, 0];
    const ring = numAnchors > 1 ? numAnchors - 1 : 1;
    const k = index - 1;
    const ang = -Math.PI / 2 + (k * 2 * Math.PI) / ring;
    return [Math.cos(ang) * RING_RADIUS, Math.sin(ang) * RING_RADIUS];
  }

  function anchorPos(index) {
    for (const n of nodes.values()) {
      if (n.isAnchor && n.anchorIndex === index) return [n.nx, n.ny];
    }
    return anchorDefault(index);
  }

  function frac(x) {
    return x - Math.floor(x);
  }
  // Deterministic per-id offset so concepts sharing an anchor don't overlap.
  function jitter(id) {
    const r1 = frac(Math.sin(id * 12.9898) * 43758.5453);
    const r2 = frac(Math.sin(id * 78.233) * 23421.631);
    const ang = r1 * Math.PI * 2;
    const mag = 0.05 + 0.04 * r2;
    return [Math.cos(ang) * mag, Math.sin(ang) * mag];
  }

  // The dominant theme (anchor_index) a captured concept leans toward,
  // including 'creativity' (index 0) so the centre cluster can be revealed when
  // creativity is the focused theme.
  function conceptThemeIndex(node) {
    const w = node.weights || [];
    let best = -Infinity;
    let idx = 0;
    for (let i = 0; i < w.length; i++) {
      if (w[i] > best) {
        best = w[i];
        idx = i;
      }
    }
    return idx;
  }

  // Choose which of a theme's phrases to reveal when zoomed in: the strongest
  // few, so the node stays legible. Recomputed each broadcast.
  function computeDisplayThemeIds() {
    displayThemeIds = null;
    displayThemeSlots = null;
    displayThemeCount = 0;
    if (focusId == null) return;
    const f = nodes.get(focusId);
    if (!f || !f.isAnchor) return;
    const members = [];
    for (const n of nodes.values()) {
      if (n.isAnchor || n.dead) continue;
      if (conceptThemeIndex(n) === f.anchorIndex) members.push(n);
    }
    members.sort((a, b) => (b.weight || 0) - (a.weight || 0));
    const shown = members.slice(0, DISPLAY_THEME_MAX);
    displayThemeIds = new Set(shown.map((n) => n.id));
    displayThemeSlots = new Map(shown.map((n, i) => [n.id, i]));
    displayThemeCount = shown.length;
  }

  // Lay the revealed phrases out in a compact ring around the focused theme.
  function displayThemePos(id) {
    const slot = displayThemeSlots.get(id);
    const total = displayThemeCount || 1;
    const ang = -Math.PI / 2 + (slot / total) * 2 * Math.PI;
    const ring = total > 8 ? (slot % 2 ? 0.62 : 0.42) : 0.52;
    return [Math.cos(ang) * ring, Math.sin(ang) * ring];
  }

  // Anchors other than the focused one are hidden while zoomed in; zooming a
  // theme reveals only that theme's strongest phrases.
  function isHidden(node) {
    if (focusId == null) return false;
    if (node.isAnchor) return node.id !== focusId;
    const f = nodes.get(focusId);
    if (f && f.isAnchor) return !(displayThemeIds && displayThemeIds.has(node.id));
    return false;
  }

  function computeBase(node) {
    if (focusId != null) {
      if (node.id === focusId) return [0, 0];
      if (displayThemeSlots && displayThemeSlots.has(node.id)) {
        return displayThemePos(node.id);
      }
      // Hidden phrases collapse toward the focused node (they fade out anyway).
      return [0, 0];
    }
    if (node.isAnchor) return anchorDefault(node.anchorIndex);
    const w = node.weights || [];
    let x = 0;
    let y = 0;
    let sum = 0;
    for (let i = 0; i < numAnchors; i++) {
      const wi = w[i] || 0;
      const [px, py] = anchorPos(i);
      x += wi * px;
      y += wi * py;
      sum += wi;
    }
    if (sum <= 0) return [0, 0];
    const [jx, jy] = jitter(node.id);
    return [x + jx, y + jy];
  }

  // ---- Websocket --------------------------------------------------------
  // This window is the host: it sends utterances and the reset/mic commands.
  function connect() {
    const proto = location.protocol === "https:" ? "wss" : "ws";
    const ws = new WebSocket(`${proto}://${location.host}/ws?host=1`);
    socket = ws;
    ws.onclose = () => setTimeout(connect, 1500);
    ws.onerror = () => ws.close();
    ws.onmessage = (ev) => {
      let payload;
      try {
        payload = JSON.parse(ev.data);
      } catch (_) {
        return;
      }
      if (payload && payload.type === "state") applyState(payload);
    };
  }

  function send(obj) {
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify(obj));
    }
  }
  function sendCommand(action, extra) {
    send(Object.assign({ type: "command", action }, extra));
  }
  function sendUtterance(text) {
    const t = (text || "").trim();
    if (t) send({ type: "utterance", text: t });
  }

  function makeNode(c) {
    const node = {
      id: c.id,
      label: c.label,
      isAnchor: !!c.is_anchor,
      anchorIndex: c.anchor_index,
      weights: c.weights || [],
      focus: typeof c.focus === "number" ? c.focus : 0,
      intensity: c.intensity,
      weight: c.weight,
      nx: 0,
      ny: 0,
      alpha: 0,
      pulse: 1,
      dead: false,
    };
    const [bx, by] = computeBase(node);
    node.nx = bx;
    node.ny = by;
    return node;
  }

  // The concept id of the anchor for a given theme index.
  function anchorIdForIndex(idx) {
    if (idx == null) return null;
    for (const n of nodes.values()) {
      if (n.isAnchor && n.anchorIndex === idx) return n.id;
    }
    return null;
  }

  // Track which theme the discussion is on (creativity included), releasing
  // after a quiet stretch. Only the newest utterance is inspected each broadcast.
  function updateAutoFocus(transcript) {
    const last = transcript.length ? transcript[transcript.length - 1] : null;
    const key = last ? String(last.t) : null;
    if (key && key !== lastUtteranceKey) {
      lastUtteranceKey = key;
      if (typeof last.theme === "number" && last.theme >= 0) {
        autoThemeIndex = last.theme;
        autoThemeAt = performance.now();
      }
    }
    if (autoThemeIndex != null && performance.now() - autoThemeAt > AUTO_ZOOM_HOLD_MS) {
      autoThemeIndex = null;
    }
  }

  function applyState(state) {
    for (const c of state.concepts) {
      if (c.is_anchor) numAnchors = Math.max(numAnchors, c.anchor_index + 1);
    }

    const seen = new Set();
    for (const c of state.concepts) {
      seen.add(c.id);
      const existing = nodes.get(c.id);
      if (existing) {
        if (c.weight > existing.weight + 1e-6) existing.pulse = 1;
        existing.weights = c.weights || existing.weights;
        existing.focus = typeof c.focus === "number" ? c.focus : 0;
        existing.intensity = c.intensity;
        existing.weight = c.weight;
        existing.label = c.label;
        existing.dead = false;
      } else {
        nodes.set(c.id, makeNode(c));
      }
    }
    for (const [id, node] of nodes) {
      if (!seen.has(id)) node.dead = true;
    }

    edges = state.edges || [];
    themeEdges = state.theme_edges || [];
    applyServerMicState(state);
    collectTranscript(state.transcript || []);

    // Auto-zoom follows the live theme (always on for the projection).
    updateAutoFocus(state.transcript || []);
    focusId = anchorIdForIndex(autoThemeIndex);
    computeDisplayThemeIds();
  }

  // ---- Microphone (browser Web Speech API) ------------------------------
  const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
  const micSupported = !!SpeechRec;
  let recognition = null;

  function setMicUI(on) {
    micOn = on;
    if (recIndicator) recIndicator.classList.toggle("on", on);
    if (recLabel) recLabel.textContent = on ? "recording" : "mic off";
  }

  function startMic() {
    if (!micSupported) return;
    if (!recognition) {
      recognition = new SpeechRec();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = "en-US";
      recognition.onresult = (e) => {
        for (let i = e.resultIndex; i < e.results.length; i++) {
          const res = e.results[i];
          if (res.isFinal) sendUtterance(res[0].transcript.trim());
        }
      };
      recognition.onerror = (e) => {
        if (e.error === "not-allowed" || e.error === "service-not-allowed") {
          if (recLabel) recLabel.textContent = "mic blocked";
          setMicUI(false);
        }
      };
      recognition.onend = () => {
        // The service stops after pauses; restart while the user wants it on.
        if (micOn) {
          try {
            recognition.start();
          } catch (_) {
            /* already starting */
          }
        }
      };
    }
    setMicUI(true);
    try {
      recognition.start();
    } catch (_) {
      /* already started */
    }
  }

  function stopMic() {
    setMicUI(false);
    if (recognition) {
      try {
        recognition.stop();
      } catch (_) {
        /* not running */
      }
    }
  }

  // Fallback for browsers without the Web Speech API (Firefox/Safari): use the
  // server's own microphone. The UI follows the broadcast server_mic state.
  let serverMicAvailable = null;
  function applyServerMicState(state) {
    if (micSupported) return;
    if (typeof state.server_mic_available === "boolean") {
      serverMicAvailable = state.server_mic_available;
    }
    if (serverMicAvailable === false) {
      if (recLabel) recLabel.textContent = "no mic";
      return;
    }
    if (serverMicAvailable) setMicUI(!!state.server_mic);
  }

  function toggleMic() {
    if (micSupported) {
      if (micOn) stopMic();
      else startMic();
    } else if (serverMicAvailable) {
      sendCommand("mic", { on: !micOn });
    }
  }

  // ---- Fullscreen + clear -----------------------------------------------
  function toggleFullscreen() {
    const el = document.documentElement;
    if (!document.fullscreenElement && !document.webkitFullscreenElement) {
      (el.requestFullscreen || el.webkitRequestFullscreen || function () {}).call(el);
    } else {
      (document.exitFullscreen || document.webkitExitFullscreen || function () {}).call(document);
    }
  }

  function clearSession() {
    // Fade out captured concepts immediately; the server reset keeps the anchors
    // and clears the transcript.
    focusId = null;
    autoThemeIndex = null;
    for (const node of nodes.values()) {
      if (!node.isAnchor) node.dead = true;
    }
    sendCommand("reset");
  }

  window.addEventListener("keydown", (e) => {
    const t = e.target;
    if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA")) return;
    if (e.code === "Space" || e.key === " ") {
      e.preventDefault();
      toggleMic();
    } else if (e.key === "f" || e.key === "F") {
      toggleFullscreen();
    } else if (e.key === "c" || e.key === "C") {
      clearSession();
    }
  });

  // ---- Curated graph (read-only mirror of /presentation) ----------------
  // Authored on /presentation and stored in notes.php. The local window reads
  // the online store cross-origin (CORS is enabled there); the URL is
  // configurable via ?graph=, window.GRAPH_API or a one-line graph.txt, and
  // defaults to the same-origin path (which works when served from the website).
  let curatedGraph = { nodes: [], edges: [] };
  let graphUrl = null;

  async function resolveGraphUrl() {
    const p = _params.get("graph");
    if (p) return p;
    if (window.GRAPH_API) return String(window.GRAPH_API);
    try {
      const r = await fetch("graph.txt", { cache: "no-store" });
      if (r.ok) {
        const tx = (await r.text()).trim();
        if (tx) return tx.split(/\s+/)[0];
      }
    } catch (_) {
      /* no graph.txt — use the default */
    }
    return "/presentation/notes.php?graph=1";
  }

  async function fetchGraph() {
    if (!graphUrl) return;
    try {
      const r = await fetch(graphUrl, { cache: "no-store" });
      if (r.ok && (r.headers.get("content-type") || "").includes("json")) {
        const g = await r.json();
        curatedGraph.nodes = Array.isArray(g.nodes) ? g.nodes : [];
        curatedGraph.edges = Array.isArray(g.edges) ? g.edges : [];
      }
    } catch (_) {
      /* unreachable — keep the last graph */
    }
  }

  // Resolve a graph endpoint id to world coords: a theme (matched by lowercased
  // anchor label) or a custom node.
  function curatedNodePos(id) {
    for (const n of nodes.values()) {
      if (n.isAnchor && n.label && n.label.toLowerCase() === id) return [n.nx, n.ny];
    }
    const cn = curatedGraph.nodes.find((n) => n.id === id);
    return cn ? [cn.x, cn.y] : null;
  }

  function drawGraph() {
    if (!curatedGraph.nodes.length && !curatedGraph.edges.length) return;
    ctx.save();
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";

    ctx.strokeStyle = "rgba(232, 236, 255, 0.28)";
    ctx.lineWidth = 1.2;
    for (const e of curatedGraph.edges) {
      const a = curatedNodePos(e.a);
      const b = curatedNodePos(e.b);
      if (!a || !b) continue;
      const [ax, ay] = project(a[0], a[1]);
      const [bx, by] = project(b[0], b[1]);
      ctx.beginPath();
      ctx.moveTo(ax, ay);
      ctx.lineTo(bx, by);
      ctx.stroke();
    }

    for (const n of curatedGraph.nodes) {
      const [x, y] = project(n.x, n.y);
      ctx.beginPath();
      ctx.fillStyle = "rgba(5, 6, 13, 0.65)";
      ctx.strokeStyle = "rgba(232, 236, 255, 0.85)";
      ctx.lineWidth = 1.5;
      ctx.arc(x, y, 6, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      if (n.label) {
        ctx.fillStyle = "rgba(232, 236, 255, 0.9)";
        ctx.font = '600 13px "Inter", Helvetica, Arial, sans-serif';
        ctx.fillText(n.label.toUpperCase(), x, y + 18);
      }
    }
    ctx.restore();
  }

  // ---- Transcript archive (one file per session, online) ----------------
  // Every broadcast carries the recent transcript; we accumulate the complete
  // session log (tracking the newest timestamp seen) and POST it to the online
  // notes.php every few seconds, so the audio transcript is archived alongside
  // the curated notes — surviving the laptop going down. Uses the same online
  // notes.php that serves the graph (configured via graph.txt / ?graph=).
  const SESSION_ID = (() => {
    const d = new Date();
    const p = (n) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}`;
  })();
  const sessionTranscript = [];
  let lastArchiveT = 0;
  let transcriptDirty = false;
  let notesBaseUrl = null; // e.g. https://site/presentation/notes.php

  function collectTranscript(transcript) {
    for (const e of transcript) {
      if (typeof e.t === "number" && e.t > lastArchiveT) {
        lastArchiveT = e.t;
        sessionTranscript.push({ t: e.t, text: e.text || "" });
        transcriptDirty = true;
      }
    }
  }

  function transcriptMarkdown() {
    const head = `# Transcript — ${SESSION_ID}\n\n`;
    const p = (n) => String(n).padStart(2, "0");
    const lines = sessionTranscript.map((e) => {
      const d = new Date(e.t * 1000);
      const ts = `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
      return `- \`${ts}\`  ${e.text}`;
    });
    return head + lines.join("\n") + "\n";
  }

  function transcriptUrl() {
    if (!notesBaseUrl) return null;
    return `${notesBaseUrl}${notesBaseUrl.includes("?") ? "&" : "?"}transcript=${encodeURIComponent(SESSION_ID)}`;
  }

  async function postTranscript() {
    const url = transcriptUrl();
    if (!url || !transcriptDirty || !sessionTranscript.length) return;
    transcriptDirty = false;
    try {
      await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "text/plain" },
        body: transcriptMarkdown(),
      });
    } catch (_) {
      transcriptDirty = true; // retry on the next tick
    }
  }

  // Strip the query so notes.php?graph=1 → notes.php (the shared endpoint base).
  function notesBaseFromGraph(u) {
    if (!u) return null;
    const q = u.indexOf("?");
    return q >= 0 ? u.slice(0, q) : u;
  }

  // ---- Render loop ------------------------------------------------------
  function nodeRadius(node) {
    if (node.id === focusId) return 16 + node.pulse * 5;
    if (node.isAnchor) return 8 + node.pulse * 4;
    return 3 + node.intensity * 16 + node.pulse * 6;
  }

  function tick(ts) {
    time = ts * 0.001;
    ctx.clearRect(0, 0, width, height);

    const zoomTarget = focusId != null ? FOCUS_ZOOM : 1;
    zoom += (zoomTarget - zoom) * 0.08;
    camOffsetX += (0 - camOffsetX) * 0.08;

    const ease = 0.08;
    for (const [id, node] of nodes) {
      const [bx, by] = computeBase(node);
      node.nx += (bx - node.nx) * ease;
      node.ny += (by - node.ny) * ease;
      const targetAlpha = node.dead || isHidden(node) ? 0 : 1;
      node.alpha += (targetAlpha - node.alpha) * 0.1;
      node.pulse *= 0.92;
      if (node.dead && node.alpha < 0.02) nodes.delete(id);
    }

    drawEdges();
    drawThemeEdges();
    drawNodes();
    drawGraph();

    requestAnimationFrame(tick);
  }

  // Live links woven between main theme nodes when they're discussed together;
  // they grow with repeated co-mention and fade out, so only shown in overview.
  function drawThemeEdges() {
    if (focusId != null || !themeEdges.length) return;
    ctx.lineCap = "round";
    for (const e of themeEdges) {
      const a = nodes.get(anchorIdForIndex(e.a));
      const b = nodes.get(anchorIdForIndex(e.b));
      if (!a || !b) continue;
      const s = Math.max(0, Math.min(1, e.strength || 0));
      const alpha = Math.min(a.alpha, b.alpha) * (0.14 + s * 0.55);
      if (alpha <= 0.01) continue;

      const [ax, ay] = project(a.nx, a.ny);
      const [bx, by] = project(b.nx, b.ny);
      const mx = (ax + bx) / 2;
      const my = (ay + by) / 2;
      const nx = -(by - ay);
      const ny = bx - ax;
      const len = Math.hypot(nx, ny) || 1;
      const sway = Math.sin(time * 0.5 + (e.a + e.b)) * 8 * s;
      const cx = mx + (nx / len) * sway;
      const cy = my + (ny / len) * sway;

      ctx.beginPath();
      ctx.moveTo(ax, ay);
      ctx.quadraticCurveTo(cx, cy, bx, by);
      ctx.strokeStyle = `rgba(255, 214, 138, ${alpha})`;
      ctx.lineWidth = 1 + s * 3.5;
      ctx.stroke();
    }
  }

  function drawEdges() {
    ctx.lineCap = "round";
    for (const e of edges) {
      const a = nodes.get(e.source);
      const b = nodes.get(e.target);
      if (!a || !b) continue;
      const [ax, ay] = project(a.nx, a.ny);
      const [bx, by] = project(b.nx, b.ny);
      const alpha = Math.min(a.alpha, b.alpha) * Math.max(0, e.weight - 0.25) * 0.9;
      if (alpha <= 0.01) continue;

      const mx = (ax + bx) / 2;
      const my = (ay + by) / 2;
      const nx = -(by - ay);
      const ny = bx - ax;
      const len = Math.hypot(nx, ny) || 1;
      const sway = Math.sin(time * 0.6 + (e.source + e.target)) * 12;
      const cx = mx + (nx / len) * sway;
      const cy = my + (ny / len) * sway;

      const grad = ctx.createLinearGradient(ax, ay, bx, by);
      grad.addColorStop(0, `rgba(123, 224, 255, ${alpha})`);
      grad.addColorStop(1, `rgba(192, 139, 255, ${alpha})`);

      ctx.beginPath();
      ctx.moveTo(ax, ay);
      ctx.quadraticCurveTo(cx, cy, bx, by);
      ctx.strokeStyle = grad;
      ctx.lineWidth = 0.6 + e.weight * 2.2;
      ctx.stroke();
    }
  }

  function drawNodes() {
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";

    for (const node of nodes.values()) {
      if (node.alpha < 0.02) continue;
      const isFocused = node.id === focusId;
      const [x, y] = project(node.nx, node.ny);

      // Overview: captured concepts are quiet dots clustered to their theme —
      // no halo, no label — so the diagram stays legible while data persists.
      if (!node.isAnchor && focusId == null) {
        const r = 1.6 + (node.intensity || 0) * 4.5;
        ctx.beginPath();
        ctx.fillStyle = `rgba(232, 236, 255, ${node.alpha * 0.5})`;
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.fill();
        continue;
      }

      const radius = nodeRadius(node);
      const glow = radius * 3.2;
      const accent = isFocused
        ? "255, 214, 138"
        : node.isAnchor
        ? "192, 139, 255"
        : "123, 224, 255";

      const halo = ctx.createRadialGradient(x, y, 0, x, y, glow);
      const baseAlpha =
        node.alpha *
        (isFocused ? 0.8 : node.isAnchor ? 0.6 : 0.25 + node.intensity * 0.5);
      halo.addColorStop(0, `rgba(${accent}, ${baseAlpha})`);
      halo.addColorStop(1, `rgba(${accent}, 0)`);
      ctx.beginPath();
      ctx.fillStyle = halo;
      ctx.arc(x, y, glow, 0, Math.PI * 2);
      ctx.fill();

      if (hoverId === node.id && !press) {
        ctx.beginPath();
        ctx.strokeStyle = `rgba(232, 236, 255, ${0.5 * node.alpha})`;
        ctx.lineWidth = 1.5;
        ctx.arc(x, y, radius + 7, 0, Math.PI * 2);
        ctx.stroke();
      }

      ctx.beginPath();
      ctx.fillStyle = `rgba(232, 236, 255, ${node.alpha})`;
      ctx.arc(x, y, radius, 0, Math.PI * 2);
      ctx.fill();

      // On the projection, captured phrases carry no text in overview (they are
      // dots, handled above); labels appear only when their theme is zoomed.
      const showLabel = node.isAnchor || focusId != null;
      if (!showLabel) continue;

      const fontSize = isFocused ? 24 : node.isAnchor ? 18 : 12 + node.intensity * 10;
      const weightStyle = isFocused || node.isAnchor ? "600 " : "";
      ctx.font = `${weightStyle}${fontSize}px "Inter", Helvetica, Arial, sans-serif`;
      const labelAlpha =
        isFocused || node.isAnchor
          ? node.alpha
          : node.alpha * (0.5 + node.intensity * 0.5);
      ctx.fillStyle = `rgba(232, 236, 255, ${labelAlpha})`;
      if (RADIAL_LABELS) {
        const d = Math.hypot(node.nx, node.ny);
        const a = d > 0.001 ? Math.atan2(-node.nx, node.ny) : 0;
        ctx.save();
        ctx.translate(x, y);
        ctx.rotate(a);
        ctx.fillText(node.label, 0, radius + fontSize * 0.9);
        ctx.restore();
      } else {
        ctx.fillText(node.label, x, y - radius - fontSize * 0.7);
      }
    }
  }

  // ---- Boot -------------------------------------------------------------
  connect();
  resolveGraphUrl().then((u) => {
    graphUrl = u;
    notesBaseUrl = notesBaseFromGraph(u);
    fetchGraph();
    setInterval(fetchGraph, 5000);
    setInterval(postTranscript, 15000);
  });
  // Best-effort final flush when the window closes.
  window.addEventListener("beforeunload", () => {
    const url = transcriptUrl();
    if (url && sessionTranscript.length && navigator.sendBeacon) {
      navigator.sendBeacon(url, new Blob([transcriptMarkdown()], { type: "text/plain" }));
    }
  });
  requestAnimationFrame(tick);
})();
