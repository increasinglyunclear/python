# Deployment (free) — running the live workshop

This is the simplest free setup: your **laptop** runs everything (the Python
app + the ML), and a free **Cloudflare quick tunnel** gives it a temporary
public `https`/`wss` address. The public viewer page lives on your website at
`https://the-making-of-creativity.com/live/` and connects back to your laptop.

```
visitors → the-making-of-creativity.com/live/   (static page on Infomaniak)
                     │  wss:// (the tunnel URL)
                     ▼
        cloudflared quick tunnel  →  your laptop: python -m backend.app
                                          ▲  http://localhost:8000/display  (you, Space to record)
```

No paid plan, no DNS changes. The only catch: a free quick tunnel's URL changes
each time you start it. The **session launcher** below handles that for you —
it starts the tunnel and uploads the new URL to the website automatically, so
there's nothing to paste or re-upload by hand. (The fully manual steps are kept
further down as a fallback.)

---

## The easy way — one command (auto-uploads the URL)

`deploy/run_session.py` starts the tunnel, grabs the fresh URL, and pushes it
into `ws.txt` (and `api.txt`) on your website over FTP. No manual re-upload.

**One-time:** copy the config template and fill in your Infomaniak FTP details:

```bash
cp deploy/infomaniak.example.json deploy/infomaniak.json
```

Edit `deploy/infomaniak.json`:

```json
{
  "protocol": "ftps",                  // "ftps", "ftp", or "sftp"
  "host": "your-host.infomaniak.com",  // from Infomaniak → FTP/SSH accounts
  "port": 21,                          // 21 for ftp/ftps, 22 for sftp
  "user": "your-ftp-username",
  "password": "your-ftp-password",
  "live_dir": "/the-making-of-creativity.com/live",
  "presentation_dir": "/the-making-of-creativity.com/presentation"
}
```

Find these in the Infomaniak Manager under your hosting's **FTP/SSH accounts**.
The `*_dir` paths are where the site's `live/` and `presentation/` folders live
on the server (drop `presentation_dir` if you don't use that page). If your host
only offers SFTP, set `"protocol": "sftp"`, `"port": 22`, and once run
`pip install paramiko`. This file holds your password, so it's git-ignored —
keep it on your laptop only.

**Each workshop — one command:**

```bash
python deploy/run_session.py
```

This **starts the app, opens the tunnel, and uploads the fresh `ws.txt`** for
you — no manual upload. It prints the tunnel URL and stays open for the session;
Ctrl-C stops both the app and the tunnel. Then:

1. Open the capture window: <http://localhost:8000/display> (press `F` for
   fullscreen, `Space` to start recording, `C` to clear)
2. Send people to <https://the-making-of-creativity.com/live/>.

That's the whole loop — the URL change is handled for you each run.

> Already run `python -m backend.app` yourself in another terminal? Use
> `python deploy/run_session.py --no-app` to do just the tunnel + upload.
>
> A quick tunnel's URL is **always** random per run (inherent to free quick
> tunnels). The launcher can't keep it fixed — it just re-uploads `ws.txt` so you
> never paste it by hand. For a permanent URL, see the named-tunnel note at the
> bottom.

---

## One-time setup

1. Install the tunnel tool (once):

   ```bash
   brew install cloudflared
   ```

2. Make sure the app runs (from the project folder):

   ```bash
   python -m backend.app
   ```

   Leave it running. Open <http://localhost:8000/display> — you should see the
   dark capture map. Stop it again for now (Ctrl-C) if you like.

3. Put the viewer files on the website once, in a `/live/` folder:

   ```
   live/
   ├── index.html   (from frontend/index.html)
   ├── view.css     (from frontend/view.css)
   ├── view.js      (from frontend/view.js)
   └── ws.txt       (created in step 5 — the live address)
   ```

---

## Manual fallback — step by step (if you don't use the launcher)

1. **Start the app** on your laptop (from the project folder):

   ```bash
   python -m backend.app
   ```

2. **Open the capture window** in Chrome:
   - Capture + projection: <http://localhost:8000/display>  (project this; press
     `F` for fullscreen)

   Press **`Space`** to start recording and allow the microphone. `localhost` is
   a secure context, so the mic works with no HTTPS. `C` clears between sessions.

3. **Start the tunnel** in a second terminal:

   ```bash
   cloudflared tunnel --url http://localhost:8000
   ```

   It prints a line like:

   ```
   https://tiny-forest-1234.trycloudflare.com
   ```

   Copy that address. **Keep this terminal open** for the whole session — closing
   it kills the tunnel.

4. **Turn the address into a websocket URL** by changing `https://` to `wss://`
   and adding `/ws`. For the example above:

   ```
   wss://tiny-forest-1234.trycloudflare.com/ws
   ```

5. **Update `ws.txt`** in the website's `/live/` folder so it contains exactly
   that one line, and upload it (overwrite the old one):

   ```
   wss://tiny-forest-1234.trycloudflare.com/ws
   ```

   (You only ever change this one file — never the HTML.)

6. **Send people to** <https://the-making-of-creativity.com/live/>. The page
   reads `ws.txt`, connects to your laptop through the tunnel, and shows the
   live themed view. Speak into the laptop and watch it populate.

That's the whole loop. After the session, Ctrl-C both the app and the tunnel.

---

## The editable presentation page (`/presentation`)

A black-on-white interactive diagram of the themes with editable notes. Click a
theme to zoom in and read/edit its prepared notes.

### Recommended: standalone on the website (works with the laptop off)

A tiny PHP script (`notes.php`) stores the notes on the Infomaniak server, so
the page is always live and editable — no laptop, no tunnel, no `api.txt`.
Requires standard Infomaniak **Web Hosting** (PHP enabled, which it is by
default). Upload these four files once:

```
presentation/
├── index.html          (a copy of frontend/presentation.html — see note)
├── presentation.css    (from frontend/presentation.css)
├── presentation.js     (from frontend/presentation.js)
└── notes.php           (from frontend/notes.php)
```

> **Important:** the folder URL `…/presentation/` is served by **`index.html`**,
> so upload `frontend/presentation.html` **named `index.html`** (overwrite it).
> If you also keep a `presentation.html` there, remember the directory only ever
> serves `index.html` — update that one. When you change the page markup
> (e.g. new panels), re-upload `index.html` **and** any changed `.js`/`notes.php`,
> or you'll see a stale page (or a missing button).

That's it — the prepared theme notes are **embedded inside `notes.php`**, so the
page shows the full text immediately with nothing else to upload. The page
auto-detects `notes.php`; when present it uses it for everything (no `api.txt`).
The first time you edit a theme, `notes.php` creates a `notes/` folder and saves
`notes/<theme>.md`; from then on that saved version takes precedence and
persists between sessions. (Infomaniak's default folder permissions let PHP
create that folder; nothing to set up.)

To update the prepared text later, either edit it on the live page (saves to the
server) or edit the `$DEFAULTS` block at the top of `notes.php` and re-upload.

The **References** button (bottom-left) opens an editable side panel that lives
in the same store under the `references` key (`notes/references.md`). Edit and
save it just like a theme; its starting list is seeded from the `$DEFAULTS`
block too.

The **+ Node** button (bottom-left) lets you draw your own nodes onto the
diagram: click it to drop a node, type its label, and drag it where you like.
Each node has a small handle (the ⊕ at its upper-right) — drag from that onto any
other node (a theme or another added node) to connect them. Ctrl/right-click a
node or a connection to delete it. The whole graph is saved automatically to
`notes/graph.json` via `notes.php?graph=1`, and the live site (`/`) polls the
same file, so your nodes and connections appear on `/live` within a few seconds.

> **Re-upload `notes.php`** when taking this update live — the graph store, the
> transcript-archive endpoint, and the cross-origin (CORS) headers it now sends
> are required for `+ Node`, for `/display` to read the graph, and for the online
> transcript archive. Also re-upload `index.html` (the renamed `presentation.html`)
> and `presentation.js`.

#### Showing the curated graph on the local `/display`

The local capture window overlays the curated graph by reading the **online**
`notes.php?graph=1` cross-origin (the CORS headers above allow this). Point it at
your site by dropping a one-line `graph.txt` into `frontend/` next to `main.js`:

```
https://the-making-of-creativity.com/presentation/notes.php?graph=1
```

You can also pass `?graph=<url>` on the `/display` URL, or set
`window.GRAPH_API`. With nothing configured it tries the same-origin path (which
only resolves when the page is itself served from the website). The graph is a
read-only overlay — authoring still happens on `/presentation`.

#### Archiving the audio transcript online

Using the **same** online `notes.php` (resolved from `graph.txt`), the capture
window posts the running session transcript every ~15s, plus a final flush when
the window closes. Each session writes its own file:

```
presentation/notes/transcript-YYYY-MM-DD-HHMM.md
```

So every workshop leaves a timestamped, plain-Markdown transcript on the server
alongside the curated notes — and it survives the laptop going down mid-session
(it's written continuously, not just at exit). No setup beyond `graph.txt`; if
`graph.txt` isn't configured, archiving simply no-ops. (The laptop also keeps a
local `data/session-*.json` archive, written on clean exit.)

### Alternative: served by the laptop app (the old way)

If you don't use the PHP store, the page falls back to talking to the running
app through the tunnel. Open it straight from the tunnel
(`https://<tunnel-host>/presentation`), or upload the three files above **with**
an `api.txt` (one line: the `https://…` tunnel base). In that mode reading and
saving only work while the app + tunnel are up, and saves write to the laptop's
`content/*.md`. You can override per-visit with `?api=https://<tunnel-host>`.

---

## Quick checks if nothing appears

- **Viewer is blank / not updating:** confirm `ws.txt` has the current `wss://…/ws`
  URL (the tunnel URL from *this* run), and that the `cloudflared` terminal is
  still open. You can also test directly:
  `https://the-making-of-creativity.com/live/?ws=wss://<tunnel-host>/ws`.
- **Space does nothing / "no mic":** use Chrome, allow the mic, and make sure the
  capture window is `http://localhost:8000/display` (localhost), not the tunnel URL.
- **Mixed-content error in the browser console:** the page is `https`, so the
  websocket must be `wss://` (not `ws://`). The tunnel provides `wss://`.

## If you want a stable URL later (still free, more setup)

A Cloudflare **named tunnel** is free and gives a fixed address, but it requires
moving the domain's DNS to a (free) Cloudflare account. Worth it for a permanent
installation; overkill for a one-off workshop, where the quick tunnel above is
simplest.
