"""Offline speech-to-text using faster-whisper.

Wraps a CTranslate2 Whisper model and turns a float32 audio window (already at
the model's expected 16kHz) into clean text. The model is loaded lazily so the
rest of the app (and `--help` style commands) start instantly.
"""

from __future__ import annotations

import numpy as np

from .config import CONFIG


class Transcriber:
    def __init__(
        self,
        model_name: str | None = None,
        device: str | None = None,
        compute_type: str | None = None,
        language: str | None = None,
    ) -> None:
        self.model_name = model_name or CONFIG.whisper_model
        self.device = device or CONFIG.whisper_device
        self.compute_type = compute_type or CONFIG.whisper_compute_type
        self.language = language or CONFIG.language
        self._model = None

    def _ensure_model(self):
        if self._model is None:
            # Imported here so importing this module is cheap and offline-safe.
            from faster_whisper import WhisperModel

            print(
                f"[stt] loading faster-whisper '{self.model_name}' "
                f"({self.device}/{self.compute_type})...",
                flush=True,
            )
            self._model = WhisperModel(
                self.model_name,
                device=self.device,
                compute_type=self.compute_type,
            )
            print("[stt] model ready", flush=True)
        return self._model

    def warmup(self) -> None:
        """Force model load + a tiny inference so the first real chunk is fast."""
        model = self._ensure_model()
        silence = np.zeros(CONFIG.sample_rate, dtype=np.float32)
        list(model.transcribe(silence, language=self.language)[0])

    def transcribe(self, audio: np.ndarray) -> str:
        """Transcribe a float32 mono window into a single text string."""
        model = self._ensure_model()
        audio = np.ascontiguousarray(audio, dtype=np.float32)

        segments, _info = model.transcribe(
            audio,
            language=self.language,
            beam_size=1,
            vad_filter=True,
            condition_on_previous_text=False,
        )

        parts: list[str] = []
        for segment in segments:
            text = segment.text.strip()
            # Skip empty or hallucinated low-confidence fragments.
            if len(text) < CONFIG.min_segment_chars:
                continue
            if segment.no_speech_prob is not None and segment.no_speech_prob > 0.6:
                continue
            parts.append(text)

        return " ".join(parts).strip()
