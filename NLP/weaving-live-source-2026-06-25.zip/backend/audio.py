"""Microphone capture and overlapping chunk generation.

Captures mono audio from the default (or configured) input device using
sounddevice/PortAudio, buffers it, and yields fixed-length float32 windows with
a configurable overlap. The overlap reduces the chance of clipping words that
straddle a window boundary before they reach Whisper.
"""

from __future__ import annotations

import queue
import threading
from collections import deque
from typing import Iterator

import numpy as np

from .config import CONFIG


def _sd():
    """Import sounddevice lazily so the module imports without PortAudio present."""
    import sounddevice as sd

    return sd


class MicrophoneStream:
    """Threaded microphone reader yielding overlapping audio windows.

    Audio is pushed from the PortAudio callback into a thread-safe queue, then
    assembled into windows of `chunk_seconds` with `overlap_seconds` carried
    over between consecutive windows.
    """

    def __init__(
        self,
        sample_rate: int | None = None,
        chunk_seconds: float | None = None,
        overlap_seconds: float | None = None,
        device: int | None = None,
    ) -> None:
        self.sample_rate = sample_rate or CONFIG.sample_rate
        self.chunk_seconds = chunk_seconds or CONFIG.chunk_seconds
        self.overlap_seconds = (
            CONFIG.overlap_seconds if overlap_seconds is None else overlap_seconds
        )
        self.device = device if device is not None else CONFIG.input_device

        self.chunk_samples = int(self.sample_rate * self.chunk_seconds)
        self.overlap_samples = int(self.sample_rate * self.overlap_seconds)
        self.hop_samples = max(1, self.chunk_samples - self.overlap_samples)

        self._raw_queue: "queue.Queue[np.ndarray]" = queue.Queue()
        self._stream = None
        self._stop = threading.Event()

    # -- PortAudio callback -------------------------------------------------
    def _callback(self, indata, frames, time_info, status):  # noqa: ANN001
        if status:
            # Overflows/underflows are non-fatal; surface them for debugging.
            print(f"[audio] stream status: {status}", flush=True)
        # Copy: the underlying buffer is reused by PortAudio after the callback.
        self._raw_queue.put(indata[:, 0].copy())

    # -- Lifecycle ----------------------------------------------------------
    def start(self) -> None:
        self._stop.clear()
        sd = _sd()
        self._stream = sd.InputStream(
            samplerate=self.sample_rate,
            channels=CONFIG.channels,
            dtype="float32",
            device=self.device,
            callback=self._callback,
            blocksize=0,
        )
        self._stream.start()

    def stop(self) -> None:
        self._stop.set()
        if self._stream is not None:
            self._stream.stop()
            self._stream.close()
            self._stream = None

    # -- Window generator ---------------------------------------------------
    def windows(self) -> Iterator[np.ndarray]:
        """Yield overlapping float32 windows until `stop()` is called."""
        buffer = np.zeros(0, dtype=np.float32)
        carry: deque[np.ndarray] = deque()

        while not self._stop.is_set():
            try:
                block = self._raw_queue.get(timeout=0.5)
            except queue.Empty:
                continue

            carry.append(block)
            buffer = np.concatenate([buffer, block])

            while len(buffer) >= self.chunk_samples:
                window = buffer[: self.chunk_samples].copy()
                yield window
                # Advance by hop, keeping the overlap tail for the next window.
                buffer = buffer[self.hop_samples :]

    def __enter__(self) -> "MicrophoneStream":
        self.start()
        return self

    def __exit__(self, *exc) -> None:  # noqa: ANN002
        self.stop()


def list_devices() -> str:
    """Return a human-readable list of available audio devices."""
    return str(_sd().query_devices())


if __name__ == "__main__":
    # `python -m backend.audio` prints input devices so the facilitator can pick
    # the right WW_INPUT_DEVICE index for the workshop room.
    print(list_devices())
