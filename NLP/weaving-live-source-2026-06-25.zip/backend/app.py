"""FastAPI app: serves the front end, stores shared files, broadcasts state.

Run with:  python -m backend.app   (or: uvicorn backend.app:app)

Browsers transcribe speech locally and send recognized text over the websocket;
the server embeds/clusters it into a shared concept map and broadcasts that map
to every connected client at `broadcast_interval`. Presentation notes are
read/written on the server so they are shared across clients.

For multiple clients over a network, serve over HTTPS (the browser Web Speech
API and microphone require a secure context; localhost is exempt) and set
WW_HOST=0.0.0.0.
"""

from __future__ import annotations

import asyncio
import contextlib
import os
import re

import uvicorn
from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles

from .config import CONFIG
from .session import Session

PROJECT_ROOT = os.path.dirname(os.path.dirname(__file__))
FRONTEND_DIR = os.path.join(PROJECT_ROOT, "frontend")
CONTENT_DIR = os.path.join(PROJECT_ROOT, CONFIG.content_dir)

# Only plain concept labels (letters, spaces, hyphens) — blocks path traversal.
_SAFE_LABEL = re.compile(r"^[a-z][a-z _-]*$")

app = FastAPI(title="Weaving Worlds — Live Semantic Vector Map")

# Allow the static website (a different origin) to read/write presentation notes
# through the tunnel. This is a local workshop tool, so permissive is fine.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

session = Session()


@app.on_event("startup")
async def _startup() -> None:
    # Model loading + mic open is blocking; run it off the event loop.
    await asyncio.to_thread(session.start)


@app.on_event("shutdown")
async def _shutdown() -> None:
    await asyncio.to_thread(session.stop)


@app.get("/")
async def index() -> FileResponse:
    """Online read-only viewer: black-on-white, concepts arranged by category."""
    return FileResponse(os.path.join(FRONTEND_DIR, "index.html"))


@app.get("/display")
async def display() -> FileResponse:
    """The single capture + projection window: a keyboard-driven live map that
    records (Space), goes fullscreen (F) and clears (C). ML runs in the background
    and the map is broadcast to every read-only viewer (/ and /live)."""
    return FileResponse(os.path.join(FRONTEND_DIR, "capture.html"))


@app.get("/presentation")
async def presentation() -> FileResponse:
    """Editable black-on-white reader of the prepared theme notes."""
    return FileResponse(os.path.join(FRONTEND_DIR, "presentation.html"))


@app.get("/themes")
async def themes() -> JSONResponse:
    """The ordered theme list (the seed anchors), for the presentation reader."""
    return JSONResponse({"themes": list(CONFIG.anchor_terms)})


@app.get("/content/{label}")
async def content(label: str) -> PlainTextResponse:
    """Return the presentation notes for a concept, read fresh from disk."""
    key = label.strip().lower()
    if not _SAFE_LABEL.match(key):
        return PlainTextResponse("", status_code=404)
    for ext in (".md", ".txt"):
        path = os.path.join(CONTENT_DIR, key + ext)
        if os.path.isfile(path):
            with open(path, encoding="utf-8") as fh:
                return PlainTextResponse(fh.read())
    return PlainTextResponse("", status_code=404)


@app.put("/content/{label}")
async def save_content(label: str, request: Request) -> PlainTextResponse:
    """Persist edited theme notes back to content/<label>.md."""
    key = label.strip().lower()
    if not _SAFE_LABEL.match(key):
        return PlainTextResponse("invalid label", status_code=400)
    os.makedirs(CONTENT_DIR, exist_ok=True)
    text = (await request.body()).decode("utf-8")
    path = os.path.join(CONTENT_DIR, key + ".md")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text)
    return PlainTextResponse("ok")


async def _broadcast(websocket: WebSocket) -> None:
    while True:
        await websocket.send_json(session.latest_payload())
        await asyncio.sleep(CONFIG.broadcast_interval)


def _handle_command(message: dict) -> None:
    action = message.get("action")
    if action == "remove":
        cid = message.get("id")
        if isinstance(cid, int):
            session.remove_concept(cid)
    elif action == "focus":
        cid = message.get("id")
        session.set_focus(cid if isinstance(cid, int) else None)
    elif action == "unfocus":
        session.set_focus(None)
    elif action == "mic":
        if bool(message.get("on")):
            session.start_server_mic()
        else:
            session.stop_server_mic()
    elif action == "reset":
        session.reset()


async def _receive(websocket: WebSocket) -> None:
    while True:
        message = await websocket.receive_json()
        if not isinstance(message, dict):
            continue
        kind = message.get("type")
        if kind == "utterance":
            text = message.get("text")
            if isinstance(text, str):
                # Embedding/KeyBERT are blocking; keep them off the event loop.
                await asyncio.to_thread(session.ingest_text, text)
        elif kind == "command":
            _handle_command(message)


@app.websocket("/ws")
async def ws_endpoint(websocket: WebSocket) -> None:
    await websocket.accept()
    # Only the host connection (?host=1) may send utterances/commands; every
    # other client is read-only and just receives the broadcast.
    is_host = websocket.query_params.get("host") == "1"
    tasks = [asyncio.create_task(_broadcast(websocket))]
    if is_host:
        tasks.append(asyncio.create_task(_receive(websocket)))
    try:
        await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
    except WebSocketDisconnect:
        pass
    finally:
        for task in tasks:
            task.cancel()
        with contextlib.suppress(Exception):
            await websocket.close()


# Static assets (main.js, style.css). Mounted last so "/" and "/ws" take priority.
app.mount("/", StaticFiles(directory=FRONTEND_DIR, html=True), name="static")


def main() -> None:
    # Load the ML models on the *main* thread before uvicorn starts. Some native
    # libraries (OpenMP / Accelerate BLAS) crash when first initialised on a
    # worker thread on macOS, which is where the startup hook would otherwise run
    # them (via asyncio.to_thread). Pre-warming here makes session.start()'s own
    # warmup a no-op, so it runs safely in the background thread.
    print("[app] pre-warming models (first run downloads them)...", flush=True)
    # Whisper (ctranslate2) must initialise before the embedder (torch) or it
    # segfaults on macOS; this is a no-op when the server mic is off/unavailable.
    session.prewarm_server_mic()
    session.concepts.warmup()
    print("[app] models ready", flush=True)
    uvicorn.run(app, host=CONFIG.host, port=CONFIG.port, log_level="info")


if __name__ == "__main__":
    main()
