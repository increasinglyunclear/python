"""Key-concept extraction, embedding and the living concept store.

This is the "nonhuman mediator": it reads the rolling transcript, surfaces key
phrases with KeyBERT, embeds them with a local sentence-transformer, and folds
them into a store of concepts. Near-duplicate phrases are merged by cosine
similarity, each concept accrues weight as it recurs, and all concepts slowly
decay so the map reflects what the room is talking about *now*.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field

import numpy as np

from .config import CONFIG


# A small safety-net stoplist on top of KeyBERT's english stop_words, catching
# filler that occasionally slips through as part of an n-gram.
_EXTRA_STOPWORDS = {
    "the", "a", "an", "and", "or", "but", "if", "so", "yeah", "okay", "ok",
    "um", "uh", "like", "just", "really", "kind", "sort", "thing", "things",
    "gonna", "wanna", "lot", "bit", "stuff", "actually", "basically", "right",
    "well", "mean", "know", "think", "going", "want", "got", "get",
}


def _l2_normalize(vec: np.ndarray) -> np.ndarray:
    norm = np.linalg.norm(vec)
    if norm == 0:
        return vec
    return vec / norm


@dataclass
class Concept:
    cid: int
    label: str
    embedding: np.ndarray  # L2-normalized
    weight: float = 1.0
    count: int = 1
    first_seen: float = field(default_factory=time.time)
    last_seen: float = field(default_factory=time.time)
    # All surface forms that merged into this concept (for archival/interest).
    aliases: set[str] = field(default_factory=set)
    # Seed anchors scaffold the map: fixed, never decayed/pruned.
    is_anchor: bool = False
    anchor_index: int = -1


class ConceptEngine:
    """Holds the embedding model, the KeyBERT extractor and the concept store."""

    def __init__(self) -> None:
        self._embedder = None
        self._keybert = None
        self._warmed = False
        self._lock = threading.Lock()
        self._concepts: dict[int, Concept] = {}
        self._next_id = 0
        # Labels the facilitator has explicitly removed; never re-added.
        self._banned: set[str] = set()

    # -- Lazy model loading -------------------------------------------------
    def _ensure_models(self):
        if self._embedder is None:
            from sentence_transformers import SentenceTransformer

            print(f"[concepts] loading embedder '{CONFIG.embedding_model}'...", flush=True)
            self._embedder = SentenceTransformer(CONFIG.embedding_model)
            print("[concepts] embedder ready", flush=True)
        if self._keybert is None:
            from keybert import KeyBERT

            self._keybert = KeyBERT(model=self._embedder)
        return self._embedder, self._keybert

    def warmup(self) -> None:
        if self._warmed:
            return
        embedder, keybert = self._ensure_models()
        embedder.encode(["warmup"], show_progress_bar=False)
        keybert.extract_keywords("a short warmup sentence about ideas")
        self._warmed = True

    # -- Seed anchors -------------------------------------------------------
    def seed_anchors(self) -> None:
        """Create the fixed scaffold concepts from config.anchor_terms.

        The first term is the centre; each anchor's embedding is a *prototype* —
        the mean of a few seed phrases (config.anchor_seeds) plus the term
        itself — so spoken talk is drawn to the theme it really belongs to, not
        just to a lexical match on one word.
        """
        with self._lock:
            for index, term in enumerate(CONFIG.anchor_terms):
                label = term.strip().lower()
                seeds = CONFIG.anchor_seeds.get(label, ())
                phrases = [label] + [s.strip().lower() for s in seeds if s.strip()]
                emb = self._prototype(phrases)
                self._concepts[self._next_id] = Concept(
                    cid=self._next_id,
                    label=label,
                    embedding=emb,
                    weight=10.0,
                    is_anchor=True,
                    anchor_index=index,
                    aliases={label},
                )
                self._next_id += 1

    def anchors(self) -> list[Concept]:
        with self._lock:
            anchors = [c for c in self._concepts.values() if c.is_anchor]
        return sorted(anchors, key=lambda c: c.anchor_index)

    # -- Embedding ----------------------------------------------------------
    def embed(self, text: str) -> np.ndarray:
        embedder, _ = self._ensure_models()
        vec = embedder.encode([text], show_progress_bar=False)[0]
        return _l2_normalize(np.asarray(vec, dtype=np.float32))

    def _prototype(self, phrases: list[str]) -> np.ndarray:
        """An L2-normalized mean embedding of several seed phrases."""
        phrases = [p for p in phrases if p]
        if not phrases:
            return np.zeros(0, dtype=np.float32)
        embedder, _ = self._ensure_models()
        vecs = embedder.encode(phrases, show_progress_bar=False)
        mean = np.mean(np.asarray(vecs, dtype=np.float32), axis=0)
        return _l2_normalize(mean)

    # -- Extraction ---------------------------------------------------------
    def extract_phrases(self, text: str) -> list[str]:
        """Pull key phrases from a transcript window using KeyBERT + MMR."""
        if not text or not text.strip():
            return []
        _, keybert = self._ensure_models()
        try:
            keywords = keybert.extract_keywords(
                text,
                keyphrase_ngram_range=(
                    CONFIG.keyphrase_ngram_min,
                    CONFIG.keyphrase_ngram_max,
                ),
                stop_words="english",
                use_mmr=True,
                diversity=CONFIG.keyphrase_diversity,
                top_n=CONFIG.keyphrases_per_chunk,
            )
        except ValueError:
            # KeyBERT raises on inputs with no candidate words (e.g. all stopwords).
            return []
        return [kw.strip().lower() for kw, _score in keywords if kw.strip()]

    def _acceptable(self, phrase: str) -> bool:
        """Reject stopwords, fillers, numbers and removed/banned phrases."""
        if len(phrase) < CONFIG.min_phrase_chars:
            return False
        if phrase in self._banned:
            return False
        if not any(ch.isalpha() for ch in phrase):
            return False
        # A single common filler word on its own is not a concept.
        if " " not in phrase and phrase in _EXTRA_STOPWORDS:
            return False
        return True

    # -- Store updates ------------------------------------------------------
    def ingest(self, text: str) -> list[str]:
        """Extract concepts from `text` and merge them into the store.

        Returns the labels of concepts that were reinforced or newly created.
        """
        phrases = self.extract_phrases(text)
        touched: list[str] = []
        now = time.time()

        with self._lock:
            for phrase in phrases:
                if not self._acceptable(phrase):
                    continue
                emb = self.embed(phrase)
                match = self._find_match(emb)
                if match is None:
                    concept = Concept(
                        cid=self._next_id,
                        label=phrase,
                        embedding=emb,
                        aliases={phrase},
                    )
                    self._concepts[self._next_id] = concept
                    self._next_id += 1
                    touched.append(phrase)
                else:
                    # Reinforce: bump weight/count, refresh recency.
                    match.weight += 1.0
                    match.count += 1
                    match.last_seen = now
                    match.aliases.add(phrase)
                    # Anchors keep a fixed embedding so clusters stay put;
                    # ordinary concepts gently drift toward recent usage.
                    if not match.is_anchor:
                        match.embedding = _l2_normalize(
                            0.85 * match.embedding + 0.15 * emb
                        )
                        if len(phrase) < len(match.label):
                            match.label = phrase
                    touched.append(match.label)

        return touched

    def _find_match(self, emb: np.ndarray) -> Concept | None:
        best: Concept | None = None
        best_sim = CONFIG.merge_threshold
        for concept in self._concepts.values():
            sim = float(np.dot(emb, concept.embedding))
            if sim >= best_sim:
                best_sim = sim
                best = concept
        return best

    # -- Decay + pruning ----------------------------------------------------
    def decay_and_prune(self, protect_ids: set[int] | None = None) -> None:
        """Apply recency decay and prune faint/overflowing concepts.

        Anchors are exempt: they never decay, never prune, and do not count
        toward the visible-concept cap. Ids in `protect_ids` (e.g. the currently
        focused concept) are kept regardless of weight.
        """
        protect = protect_ids or set()
        with self._lock:
            anchors = {cid: c for cid, c in self._concepts.items() if c.is_anchor}
            others = {cid: c for cid, c in self._concepts.items() if not c.is_anchor}

            if CONFIG.persist_concepts:
                # Persistent mode: nothing decays or prunes; captures accumulate
                # for the whole session. Only the safety cap below applies.
                survivors = dict(others)
            else:
                for concept in others.values():
                    concept.weight *= CONFIG.decay_factor
                survivors = {
                    cid: c
                    for cid, c in others.items()
                    if c.weight >= CONFIG.prune_weight or cid in protect
                }

            if len(survivors) > CONFIG.max_concepts:
                ranked = sorted(
                    survivors.values(),
                    key=lambda c: (c.cid in protect, c.weight),
                    reverse=True,
                )
                survivors = {c.cid: c for c in ranked[: CONFIG.max_concepts]}
                # Ensure protected ids stay even if the cap clipped them.
                for cid in protect:
                    if cid in others and cid not in survivors:
                        survivors[cid] = others[cid]

            self._concepts = {**anchors, **survivors}

    # -- Removal ------------------------------------------------------------
    def remove_concept(self, cid: int) -> bool:
        """Remove a concept by id and ban its surface forms from returning.

        Anchors are protected and cannot be removed this way.
        """
        with self._lock:
            concept = self._concepts.get(cid)
            if concept is None or concept.is_anchor:
                return False
            self._banned.add(concept.label)
            self._banned.update(concept.aliases)
            del self._concepts[cid]
            return True

    def reset(self) -> None:
        """Drop all captured concepts and un-ban everything; keep the anchors."""
        with self._lock:
            self._concepts = {
                cid: c for cid, c in self._concepts.items() if c.is_anchor
            }
            self._banned.clear()

    # -- Access -------------------------------------------------------------
    def snapshot(self) -> list[Concept]:
        with self._lock:
            return list(self._concepts.values())
