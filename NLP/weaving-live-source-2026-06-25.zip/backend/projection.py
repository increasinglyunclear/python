"""Anchor-affinity weighting + edge weaving.

The live layout is anchored: a fixed set of seed concepts scaffold the space
(the front end positions them — centre + ring), and every spoken concept is
placed by how strongly it relates to each anchor. This module computes, per
concept, a softmax distribution of affinities over the anchors (the front end
turns that into a position) and the similarity "threads" between concepts.

A legacy PCA/UMAP projection is retained as a fallback for non-anchored use.
"""

from __future__ import annotations

import numpy as np

from .concepts import Concept
from .config import CONFIG


class Projector:
    def __init__(self, mode: str | None = None) -> None:
        self.mode = (mode or CONFIG.projection_mode).lower()
        # Previous layout keyed by concept id, used to stabilize orientation.
        self._prev: dict[int, np.ndarray] = {}

    # -- Anchored layout ----------------------------------------------------
    def anchor_weights(self, concepts: list[Concept]) -> dict[int, list[float]]:
        """Return {concept_id: [w_0, ..., w_{A-1}]} over the A anchors.

        Anchors get a one-hot vector at their own index; ordinary concepts get
        a softmax over cosine similarity to each anchor, so the front end can
        place them as a weighted blend of anchor positions.
        """
        anchors = sorted(
            (c for c in concepts if c.is_anchor), key=lambda c: c.anchor_index
        )
        num = len(anchors)
        if num == 0:
            return {}

        anchor_mat = np.vstack([a.embedding for a in anchors]).astype(np.float32)
        temp = max(CONFIG.anchor_temperature, 1e-3)

        weights: dict[int, list[float]] = {}
        for c in concepts:
            if c.is_anchor:
                vec = [0.0] * num
                vec[c.anchor_index] = 1.0
                weights[c.cid] = vec
                continue
            sims = anchor_mat @ c.embedding
            scaled = sims / temp
            scaled -= scaled.max()
            exp = np.exp(scaled)
            soft = exp / (exp.sum() + 1e-9)
            weights[c.cid] = [float(v) for v in soft]
        return weights

    def focus_similarities(
        self, concepts: list[Concept], focus_id: int
    ) -> dict[int, float]:
        """Cosine similarity of every concept to the focused concept.

        Used by the front end to lay concepts out radially around a single
        focused node (closer = more related).
        """
        focus = next((c for c in concepts if c.cid == focus_id), None)
        if focus is None:
            return {}
        fe = focus.embedding
        return {c.cid: float(np.dot(c.embedding, fe)) for c in concepts}

    # -- Public API (legacy PCA/UMAP) ---------------------------------------
    def project(self, concepts: list[Concept]) -> dict[int, tuple[float, float]]:
        """Return {concept_id: (x, y)} with coords normalized to [-1, 1]."""
        n = len(concepts)
        if n == 0:
            self._prev = {}
            return {}
        if n == 1:
            coords = {concepts[0].cid: (0.0, 0.0)}
            self._prev = {concepts[0].cid: np.zeros(2, dtype=np.float32)}
            return coords

        matrix = np.vstack([c.embedding for c in concepts]).astype(np.float32)

        if self.mode == "umap" and n >= 4:
            raw = self._project_umap(matrix)
        else:
            raw = self._project_pca(matrix)

        raw = self._stabilize(concepts, raw)
        raw = self._normalize(raw)

        coords: dict[int, tuple[float, float]] = {}
        new_prev: dict[int, np.ndarray] = {}
        for concept, point in zip(concepts, raw):
            coords[concept.cid] = (float(point[0]), float(point[1]))
            new_prev[concept.cid] = point
        self._prev = new_prev
        return coords

    def edges(self, concepts: list[Concept]) -> list[dict]:
        """k-nearest-neighbour threads above the similarity threshold."""
        n = len(concepts)
        if n < 2:
            return []

        matrix = np.vstack([c.embedding for c in concepts]).astype(np.float32)
        # Cosine similarity (embeddings are already L2-normalized).
        sims = matrix @ matrix.T
        np.fill_diagonal(sims, -1.0)

        seen: set[tuple[int, int]] = set()
        edges: list[dict] = []
        k = CONFIG.edge_neighbors
        for i in range(n):
            order = np.argsort(sims[i])[::-1][:k]
            for j in order:
                sim = float(sims[i, j])
                if sim < CONFIG.edge_threshold:
                    continue
                a, b = concepts[i].cid, concepts[int(j)].cid
                key = (a, b) if a < b else (b, a)
                if key in seen:
                    continue
                seen.add(key)
                edges.append({"source": key[0], "target": key[1], "weight": sim})
        return edges

    # -- Backends -----------------------------------------------------------
    def _project_pca(self, matrix: np.ndarray) -> np.ndarray:
        from sklearn.decomposition import PCA

        components = min(2, matrix.shape[0], matrix.shape[1])
        pca = PCA(n_components=components)
        out = pca.fit_transform(matrix)
        if out.shape[1] == 1:
            out = np.hstack([out, np.zeros((out.shape[0], 1), dtype=np.float32)])
        return out.astype(np.float32)

    def _project_umap(self, matrix: np.ndarray) -> np.ndarray:
        try:
            import umap  # type: ignore
        except ImportError:
            return self._project_pca(matrix)
        reducer = umap.UMAP(
            n_components=2,
            n_neighbors=min(15, matrix.shape[0] - 1),
            min_dist=0.2,
            metric="cosine",
        )
        return reducer.fit_transform(matrix).astype(np.float32)

    # -- Stabilization + scaling -------------------------------------------
    def _stabilize(self, concepts: list[Concept], raw: np.ndarray) -> np.ndarray:
        """Align `raw` to the previous frame via an orthogonal Procrustes fit.

        Only concepts present in both frames drive the alignment; this keeps the
        overall orientation steady while new concepts settle in.
        """
        shared = [
            (idx, self._prev[c.cid])
            for idx, c in enumerate(concepts)
            if c.cid in self._prev
        ]
        if len(shared) < 2:
            return raw

        idxs = [s[0] for s in shared]
        prev_pts = np.vstack([s[1] for s in shared])
        cur_pts = raw[idxs]

        # Center both clouds, then solve for the best rotation/reflection.
        prev_c = prev_pts - prev_pts.mean(axis=0)
        cur_c = cur_pts - cur_pts.mean(axis=0)
        if np.linalg.norm(cur_c) < 1e-8 or np.linalg.norm(prev_c) < 1e-8:
            return raw
        u, _s, vt = np.linalg.svd(cur_c.T @ prev_c)
        rotation = u @ vt
        return raw @ rotation

    def _normalize(self, raw: np.ndarray) -> np.ndarray:
        """Scale coordinates into [-1, 1] preserving aspect ratio."""
        centered = raw - raw.mean(axis=0)
        max_abs = np.max(np.abs(centered))
        if max_abs < 1e-8:
            return centered
        return centered / max_abs
