"""Central configuration for Weaving Worlds.

All tunables live here so the live feel of the installation can be adjusted
without touching the pipeline code. Most values can also be overridden via
environment variables for quick experimentation during a workshop.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field


def _env_str(name: str, default: str) -> str:
    return os.environ.get(name, default)


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, default))
    except (TypeError, ValueError):
        return default


def _env_float(name: str, default: float) -> float:
    try:
        return float(os.environ.get(name, default))
    except (TypeError, ValueError):
        return default


def _env_bool(name: str, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


@dataclass
class Config:
    # ----- Server -----
    host: str = field(default_factory=lambda: _env_str("WW_HOST", "127.0.0.1"))
    port: int = field(default_factory=lambda: _env_int("WW_PORT", 8000))

    # ----- Audio capture -----
    sample_rate: int = field(default_factory=lambda: _env_int("WW_SAMPLE_RATE", 16000))
    channels: int = 1
    # Length of each transcription window and how much consecutive windows overlap.
    chunk_seconds: float = field(default_factory=lambda: _env_float("WW_CHUNK_SECONDS", 5.0))
    overlap_seconds: float = field(default_factory=lambda: _env_float("WW_OVERLAP_SECONDS", 1.0))
    # Input device index (None = system default). Use `python -m backend.audio` to list devices.
    input_device: int | None = field(
        default_factory=lambda: (
            int(os.environ["WW_INPUT_DEVICE"]) if os.environ.get("WW_INPUT_DEVICE") else None
        )
    )

    # ----- Speech-to-text (faster-whisper) -----
    # Server-side mic fallback (for browsers without the Web Speech API). When
    # enabled and the deps are installed, the Whisper model is pre-loaded at
    # startup *before* the embedder — ctranslate2 segfaults if loaded after
    # torch on macOS. Set WW_SERVER_MIC=0 to skip it entirely (browser-only).
    enable_server_mic: bool = field(default_factory=lambda: _env_bool("WW_SERVER_MIC", True))
    whisper_model: str = field(default_factory=lambda: _env_str("WW_WHISPER_MODEL", "base"))
    whisper_device: str = field(default_factory=lambda: _env_str("WW_WHISPER_DEVICE", "cpu"))
    whisper_compute_type: str = field(
        default_factory=lambda: _env_str("WW_WHISPER_COMPUTE", "int8")
    )
    language: str = field(default_factory=lambda: _env_str("WW_LANGUAGE", "en"))
    # Drop transcription segments below this average log-prob / above this no-speech prob.
    min_segment_chars: int = 3

    # ----- Embeddings + concept extraction -----
    embedding_model: str = field(
        default_factory=lambda: _env_str("WW_EMBED_MODEL", "all-MiniLM-L6-v2")
    )
    keyphrase_ngram_min: int = 1
    keyphrase_ngram_max: int = 3
    keyphrases_per_chunk: int = field(default_factory=lambda: _env_int("WW_KEYPHRASES", 5))
    # KeyBERT diversity (MMR). 0 = relevance only, 1 = max diversity.
    keyphrase_diversity: float = field(default_factory=lambda: _env_float("WW_DIVERSITY", 0.6))
    # Rolling transcript window (chars) handed to KeyBERT for context.
    transcript_window_chars: int = 600
    # Minimum characters for an extracted phrase to be kept as a concept.
    min_phrase_chars: int = 3

    # ----- Seed anchors -----
    # Fixed concepts that scaffold the map. The first is placed at the centre,
    # the rest in a ring around it; spoken terms cluster toward whichever anchor
    # they are most semantically similar to.
    anchor_terms: tuple[str, ...] = (
        "creativity",
        "desire",
        "process",
        "skill",
        "materiality",
        "communication",
        "technology",
    )
    # Each anchor is represented not by its bare word but by the *average*
    # embedding of a few seed phrases (a prototype), which routes spoken talk to
    # themes far more reliably than a single keyword. The anchor term itself is
    # always included; these add the surrounding sense of each theme. Tune freely.
    anchor_seeds: dict[str, tuple[str, ...]] = field(
        default_factory=lambda: {
            "creativity": (
                "creativity", "making", "imagination", "originality",
                "creative expression", "invention", "the creative act",
            ),
            "desire": (
                "desire", "longing", "motivation", "drive", "yearning",
                "wanting to make something", "intention",
            ),
            "process": (
                "process", "method", "practice", "the act of making", "workflow",
                "iteration", "procedure", "how something is made",
            ),
            "skill": (
                "skill", "craft", "mastery", "technique", "expertise",
                "ability", "competence", "know-how",
            ),
            "materiality": (
                "materiality", "material", "medium", "substance", "physical matter",
                "texture", "the material of one's domain", "the stuff things are made of",
            ),
            "communication": (
                "communication", "expression", "dialogue", "sharing",
                "conveying meaning", "audience", "speaking to others",
            ),
            "technology": (
                "technology", "artificial intelligence", "machine", "tools",
                "automation", "algorithm", "computation", "digital tools",
            ),
        }
    )
    # Softmax temperature for anchor assignment (lower = tighter clustering).
    anchor_temperature: float = field(
        default_factory=lambda: _env_float("WW_ANCHOR_TEMP", 0.12)
    )
    # Minimum cosine similarity for an utterance to be filed under a *specific*
    # theme (otherwise it only appears under the general "creativity" overview).
    quote_theme_threshold: float = field(
        default_factory=lambda: _env_float("WW_QUOTE_THEME", 0.18)
    )
    # Creativity is the centre/general theme, so it would otherwise win almost
    # every utterance and park the auto-zoom on the middle. It is allowed to win
    # the per-utterance theme only when it leads the best *specific* theme by at
    # least this margin — i.e. the talk is clearly about creativity-in-general.
    creativity_theme_margin: float = field(
        default_factory=lambda: _env_float("WW_CREATIVITY_MARGIN", 0.06)
    )

    # ----- Concept store -----
    # Two phrases with cosine similarity above this are treated as the same concept.
    merge_threshold: float = field(default_factory=lambda: _env_float("WW_MERGE_THRESHOLD", 0.8))
    # Keep every captured concept for the whole session instead of decaying it
    # away during quiet stretches. The diagram then accumulates (dots clustered
    # to each theme) rather than periodically emptying back to bare anchors.
    # Set WW_PERSIST=0 to restore the old "breathing"/recency behaviour.
    persist_concepts: bool = field(default_factory=lambda: _env_bool("WW_PERSIST", True))
    # Concept weight decays by this factor every tick (recency); keeps the map
    # breathing. Only applied when persist_concepts is off.
    decay_factor: float = field(default_factory=lambda: _env_float("WW_DECAY", 0.985))
    # Concepts whose weight falls below this are pruned (decay mode only).
    prune_weight: float = field(default_factory=lambda: _env_float("WW_PRUNE_WEIGHT", 0.05))
    # Hard cap on stored concepts. Higher when persisting (the map keeps it all);
    # near-duplicates are merged first, so this is mostly a safety ceiling.
    max_concepts: int = field(default_factory=lambda: _env_int("WW_MAX_CONCEPTS", 240))

    # ----- Projection + edges -----
    # "pca" (calm, stable) or "umap" (organic, needs umap-learn installed).
    projection_mode: str = field(default_factory=lambda: _env_str("WW_PROJECTION", "pca"))
    # Each concept connects to up to this many nearest neighbours...
    edge_neighbors: int = field(default_factory=lambda: _env_int("WW_EDGE_NEIGHBORS", 3))
    # ...provided their cosine similarity exceeds this threshold.
    edge_threshold: float = field(default_factory=lambda: _env_float("WW_EDGE_THRESHOLD", 0.35))

    # ----- Live theme co-occurrence links -----
    # A thread is woven between two main theme nodes when an utterance is clearly
    # about both at once (semantic), strengthening with repeated co-mention and
    # decaying over time. These are distinct from the curated /presentation links.
    # An utterance "touches" a theme when its similarity clears this.
    theme_link_touch: float = field(default_factory=lambda: _env_float("WW_TLINK_TOUCH", 0.26))
    # At most this many (strongest) themes per utterance can co-occur, so one
    # broad sentence doesn't wire everything together.
    theme_link_max_touch: int = field(default_factory=lambda: _env_int("WW_TLINK_MAXTOUCH", 3))
    # Weight added to a pair each time they co-occur.
    theme_link_gain: float = field(default_factory=lambda: _env_float("WW_TLINK_GAIN", 1.0))
    # Seconds over which a link's weight halves when not reinforced.
    theme_link_half_life: float = field(default_factory=lambda: _env_float("WW_TLINK_HALFLIFE", 22.0))
    # Weight that renders a link at full strength (so a single co-mention is faint).
    theme_link_full: float = field(default_factory=lambda: _env_float("WW_TLINK_FULL", 2.0))
    # Below this weight a link is dropped entirely.
    theme_link_min: float = field(default_factory=lambda: _env_float("WW_TLINK_MIN", 0.35))

    # ----- Orchestration -----
    # How often the projection + broadcast payload is recomputed (seconds).
    broadcast_interval: float = field(default_factory=lambda: _env_float("WW_BROADCAST", 1.0))
    # Keep this many recent transcript snippets for the on-screen ribbon.
    transcript_history: int = 40

    # ----- Session archival -----
    export_on_exit: bool = field(default_factory=lambda: _env_bool("WW_EXPORT", True))
    data_dir: str = field(default_factory=lambda: _env_str("WW_DATA_DIR", "data"))

    # ----- Presentation content -----
    # Directory of per-concept notes shown in presentation mode (one .md/.txt
    # per anchor term, e.g. content/creativity.md).
    content_dir: str = field(default_factory=lambda: _env_str("WW_CONTENT_DIR", "content"))


CONFIG = Config()
