"""Orchestration: shared concept map fed by text from connected browsers.

In the web/multi-client architecture the server no longer captures audio. Each
browser transcribes speech locally (Web Speech API) and sends recognized text
to the server via the websocket; the server embeds it, folds it into the shared
concept store, and broadcasts the resulting map to every connected client.

The concept map and content files are the shared source of truth; microphone
and view state (focus/presentation) live in each client.
"""

from __future__ import annotations

import json
import os
import threading
import time
from collections import deque
from datetime import datetime

import numpy as np

from .concepts import ConceptEngine
from .config import CONFIG
from .projection import Projector


class Session:
    def __init__(self) -> None:
        self.concepts = ConceptEngine()
        self.projector = Projector()

        self._transcript: deque[dict] = deque(maxlen=CONFIG.transcript_history)
        self._full_transcript: list[dict] = []
        self._rolling = ""

        self._latest: dict = {
            "type": "state",
            "concepts": [],
            "edges": [],
            "theme_edges": [],
            "transcript": [],
            "focus_id": None,
            "stats": {"concepts": 0, "utterances": 0},
        }
        self._lock = threading.Lock()
        self._stop = threading.Event()
        # Live co-occurrence links between main theme nodes: (a, b) -> weight,
        # built when utterances are about two themes at once and decayed over time.
        self._theme_links: dict[tuple[int, int], float] = {}
        self._theme_links_t = time.time()
        # Id of the concept the view is currently zoomed into (None = overview).
        self._focus_id: int | None = None
        # Optional server-side microphone (fallback for browsers without the Web
        # Speech API). Only useful on the capture machine, where the server's
        # mic is the room mic.
        self._server_mic_on = False
        self._mic_available: bool | None = None
        self._mic_thread: threading.Thread | None = None
        self._mic_stream = None
        self._transcriber = None
        self._mic_stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._started_at = time.time()

    # -- Lifecycle ----------------------------------------------------------
    def start(self) -> None:
        print("[session] warming up embedder (first run downloads it)...", flush=True)
        self.concepts.warmup()
        print("[session] seeding anchor concepts", flush=True)
        self.concepts.seed_anchors()
        self._rebuild_payload()
        self._started_at = time.time()

        self._thread = threading.Thread(target=self._render_loop, name="render", daemon=True)
        self._thread.start()
        print("[session] ready — waiting for transcribed text from clients", flush=True)

    def stop(self) -> None:
        self.stop_server_mic()
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=2.0)
        if CONFIG.export_on_exit:
            self.export()

    # -- Ingestion (called when a client sends recognized speech) -----------
    def ingest_text(self, text: str) -> None:
        text = (text or "").strip()
        if not text:
            return

        now = time.time()
        scores = self._anchor_scores(text)
        theme = self._utterance_theme(scores)
        entry = {
            "t": now,
            "text": text,
            "theme": theme,
        }
        with self._lock:
            self._transcript.append(entry)
            self._full_transcript.append(entry)
            self._rolling = (self._rolling + " " + text)[-CONFIG.transcript_window_chars:]
            rolling = self._rolling
        self._update_theme_links(scores, now)
        self.concepts.ingest(rolling)
        self._rebuild_payload()

    def _anchor_scores(self, text: str) -> dict[int, float]:
        """Cosine similarity of an utterance to each theme anchor, keyed by
        anchor_index. Empty if there are no anchors or embedding fails."""
        anchors = self.concepts.anchors()
        if not anchors:
            return {}
        try:
            emb = self.concepts.embed(text)
        except Exception:
            return {}
        return {a.anchor_index: float(np.dot(emb, a.embedding)) for a in anchors}

    def _utterance_theme(self, scores: dict[int, float]) -> int | None:
        """Best-matching theme for a whole utterance, used to file supporting
        quotes and drive the auto-zoom. Returns a specific theme
        (anchor_index >= 1) when one clearly dominates, 'creativity'
        (anchor_index 0) when the talk is clearly about creativity-in-general,
        or None when nothing stands out.
        """
        if not scores:
            return None
        specific = {i: s for i, s in scores.items() if i >= 1}
        best_specific_idx, best_specific = None, -1.0
        for i, s in specific.items():
            if s > best_specific:
                best_specific, best_specific_idx = s, i
        creativity = scores.get(0, -1.0)
        # Creativity is the centre, so only let it win when it clearly leads the
        # strongest specific theme — otherwise the marked sub-themes take
        # priority and the view keeps exploring the ring.
        if (
            creativity >= CONFIG.quote_theme_threshold
            and creativity >= best_specific + CONFIG.creativity_theme_margin
        ):
            return 0
        if best_specific_idx is not None and best_specific >= CONFIG.quote_theme_threshold:
            return best_specific_idx
        return None

    # -- Live theme co-occurrence links -------------------------------------
    def _update_theme_links(self, scores: dict[int, float], now: float) -> None:
        """Strengthen the link between every pair of themes an utterance is
        clearly about (semantic co-occurrence)."""
        touched = sorted(
            (i for i, s in scores.items() if s >= CONFIG.theme_link_touch),
            key=lambda i: scores[i],
            reverse=True,
        )[: CONFIG.theme_link_max_touch]
        if len(touched) < 2:
            return
        touched.sort()
        with self._lock:
            self._decay_theme_links(now)
            for ai in range(len(touched)):
                for bi in range(ai + 1, len(touched)):
                    key = (touched[ai], touched[bi])
                    self._theme_links[key] = (
                        self._theme_links.get(key, 0.0) + CONFIG.theme_link_gain
                    )

    def _decay_theme_links(self, now: float) -> None:
        """Exponentially decay link weights toward zero; prune the negligible.
        Caller must hold ``self._lock``."""
        dt = now - self._theme_links_t
        self._theme_links_t = now
        if dt <= 0 or not self._theme_links:
            return
        factor = 0.5 ** (dt / CONFIG.theme_link_half_life)
        for key in list(self._theme_links):
            w = self._theme_links[key] * factor
            if w < CONFIG.theme_link_min:
                del self._theme_links[key]
            else:
                self._theme_links[key] = w

    def _theme_edges_payload(self) -> list[dict]:
        """Current theme links as broadcastable edges, decayed to now. Strength
        is normalized so a single co-mention reads faint and repeated ones grow."""
        with self._lock:
            self._decay_theme_links(time.time())
            items = list(self._theme_links.items())
        out = []
        for (a, b), w in items:
            out.append({"a": a, "b": b, "strength": min(1.0, w / CONFIG.theme_link_full)})
        return out

    # -- Controls (shared across clients) -----------------------------------
    def set_focus(self, cid: int | None) -> None:
        self._focus_id = cid
        self._rebuild_payload()

    # -- Server-side microphone (Web Speech API fallback) -------------------
    def server_mic_available(self) -> bool:
        """True if the server-mic fallback is enabled and its STT/audio deps are
        installed. Computed once via import specs so we never load the heavy
        libs just to check."""
        if not CONFIG.enable_server_mic:
            return False
        if self._mic_available is None:
            try:
                import importlib.util

                self._mic_available = (
                    importlib.util.find_spec("sounddevice") is not None
                    and importlib.util.find_spec("faster_whisper") is not None
                )
            except Exception:
                self._mic_available = False
        return self._mic_available

    def prewarm_server_mic(self) -> None:
        """Load the Whisper model at startup, *before* the embedder. ctranslate2
        segfaults on macOS if it initialises after torch, so order matters."""
        if not self.server_mic_available():
            return
        from .transcribe import Transcriber

        print("[app] pre-loading speech-to-text (server-mic fallback)...", flush=True)
        self._transcriber = Transcriber()
        try:
            self._transcriber._ensure_model()
        except Exception as exc:  # pragma: no cover - hardware/runtime dependent
            print(f"[server-mic] preload failed: {exc}", flush=True)
            self._mic_available = False
            self._transcriber = None

    def start_server_mic(self) -> None:
        if self._server_mic_on or not self.server_mic_available():
            return
        from .audio import MicrophoneStream

        if self._transcriber is None:
            # Not pre-warmed (model loads here): only safe if torch isn't loaded
            # yet, which is unusual at runtime. Prefer prewarm_server_mic().
            from .transcribe import Transcriber

            self._transcriber = Transcriber()
            try:
                self._transcriber._ensure_model()
            except Exception as exc:  # pragma: no cover - hardware dependent
                print(f"[server-mic] could not load model: {exc}", flush=True)
                self._mic_available = False
                self._rebuild_payload()
                return

        self._mic_stop.clear()
        self._mic_stream = MicrophoneStream()
        self._server_mic_on = True
        self._mic_thread = threading.Thread(target=self._mic_loop, name="server-mic", daemon=True)
        self._mic_thread.start()
        print("[server-mic] capturing from this machine's microphone", flush=True)
        self._rebuild_payload()

    def stop_server_mic(self) -> None:
        self._mic_stop.set()
        stream = self._mic_stream
        if stream is not None:
            try:
                stream.stop()
            except Exception:
                pass
        self._mic_stream = None
        self._server_mic_on = False
        self._rebuild_payload()

    def _mic_loop(self) -> None:
        try:
            self._mic_stream.start()
            for window in self._mic_stream.windows():
                if self._mic_stop.is_set():
                    break
                text = self._transcriber.transcribe(window)
                if text:
                    self.ingest_text(text)
        except Exception as exc:  # pragma: no cover - hardware/runtime dependent
            print(f"[server-mic] capture stopped: {exc}", flush=True)
        finally:
            self._server_mic_on = False
            self._rebuild_payload()

    def remove_concept(self, cid: int) -> bool:
        removed = self.concepts.remove_concept(cid)
        if removed:
            if self._focus_id == cid:
                self._focus_id = None
            self._rebuild_payload()
        return removed

    def reset(self) -> None:
        """Clear the screen and start fresh: drop captured concepts, focus and
        transcript, but keep the seed anchors.
        """
        self.concepts.reset()
        self._focus_id = None
        with self._lock:
            self._transcript.clear()
            self._full_transcript = []
            self._rolling = ""
            self._theme_links.clear()
            self._theme_links_t = time.time()
        self._started_at = time.time()
        self._rebuild_payload()

    # -- Projection + payload ----------------------------------------------
    def _render_loop(self) -> None:
        while not self._stop.is_set():
            time.sleep(CONFIG.broadcast_interval)
            protect = {self._focus_id} if self._focus_id is not None else None
            self.concepts.decay_and_prune(protect)
            self._rebuild_payload()

    def _rebuild_payload(self) -> None:
        concepts = self.concepts.snapshot()
        weights = self.projector.anchor_weights(concepts)
        edges = self.projector.edges(concepts)

        focus_id = self._focus_id
        if focus_id is not None and not any(c.cid == focus_id for c in concepts):
            focus_id = None
            self._focus_id = None
        focus_sims = (
            self.projector.focus_similarities(concepts, focus_id)
            if focus_id is not None
            else {}
        )

        non_anchor = [c.weight for c in concepts if not c.is_anchor]
        max_weight = max(non_anchor, default=1.0)
        nodes = []
        for c in concepts:
            nodes.append(
                {
                    "id": c.cid,
                    "label": c.label,
                    "is_anchor": c.is_anchor,
                    "anchor_index": c.anchor_index,
                    "weights": weights.get(c.cid, []),
                    "focus": focus_sims.get(c.cid, 0.0),
                    "weight": c.weight,
                    "intensity": c.weight / max_weight if max_weight else 0.0,
                    "count": c.count,
                    "last_seen": c.last_seen,
                }
            )

        with self._lock:
            transcript = list(self._transcript)
            utterances = len(self._full_transcript)
            visible = sum(1 for c in concepts if not c.is_anchor)

        payload = {
            "type": "state",
            "concepts": nodes,
            "edges": edges,
            "theme_edges": self._theme_edges_payload(),
            "transcript": transcript,
            "focus_id": focus_id,
            "server_mic": self._server_mic_on,
            "server_mic_available": self.server_mic_available(),
            "stats": {
                "concepts": visible,
                "utterances": utterances,
                "elapsed": time.time() - self._started_at,
            },
        }
        with self._lock:
            self._latest = payload

    def latest_payload(self) -> dict:
        with self._lock:
            return self._latest

    # -- Archival -----------------------------------------------------------
    def export(self) -> str | None:
        concepts = self.concepts.snapshot()
        if not concepts and not self._full_transcript:
            return None

        os.makedirs(CONFIG.data_dir, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        path = os.path.join(CONFIG.data_dir, f"session-{stamp}.json")

        data = {
            "started_at": self._started_at,
            "ended_at": time.time(),
            "transcript": self._full_transcript,
            "concepts": [
                {
                    "id": c.cid,
                    "label": c.label,
                    "weight": c.weight,
                    "count": c.count,
                    "first_seen": c.first_seen,
                    "last_seen": c.last_seen,
                    "aliases": sorted(c.aliases),
                }
                for c in concepts
            ],
        }
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2, ensure_ascii=False)
        print(f"[session] exported session to {path}", flush=True)
        return path
