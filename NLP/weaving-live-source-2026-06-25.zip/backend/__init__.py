"""Weaving Worlds backend package.

This module runs before any submodule import, so it is the right place to set
environment safeguards that must be in effect *before* the numerical libraries
(numpy/torch/ctranslate2/onnxruntime) initialize their OpenMP runtimes.

On macOS, running inside a conda environment alongside a venv often loads two
copies of libiomp5.dylib, which aborts the process with "OMP: Error #15".
Allowing the duplicate is the standard, widely-used workaround for inference
workloads like this one. Set WW_ALLOW_OMP_DUPLICATE=0 to opt out.
"""

import os

if os.environ.get("WW_ALLOW_OMP_DUPLICATE", "1") != "0":
    os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
