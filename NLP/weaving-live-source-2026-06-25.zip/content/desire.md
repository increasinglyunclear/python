Is creativity a type of desire? Does AI dull desire? 

Is there too much mediation in the way one engages with AI, or does it help extract what this desire is about?