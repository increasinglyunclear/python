Is a desire to communicate an inalienable aspect of creativity? 

Communicate with whom – the self, the divine, the other, a community? 

How does communicating with or for a mechanistic logic change desire, process, confidence in one's domain, and the materiality of thinking?