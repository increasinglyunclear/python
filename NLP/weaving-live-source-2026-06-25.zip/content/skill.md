Is skill a necessary condition for creativity? 

What about openness – breaking it open, being free from the constraints of the "domain"? 

What happens when the "skill" is farmed out to AI? 

Is the result up-skilling, de-skilling, or something that requires an entirely new vocabulary?