Is the vulnerability of the material – its mortality, epigenetic atmosphere, material historicity – intrinsically connected to creativity? 

Does the probabilistic nature of AI prevent it from being thought of as a material?