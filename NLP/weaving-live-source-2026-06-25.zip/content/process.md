Is the creative process part of identity, attitude, style (a process of non-process)? 

Does AI make creativity too procedural? 

In other words, does process take precedence when engaging with AI, and "attitude" / or style recede?
