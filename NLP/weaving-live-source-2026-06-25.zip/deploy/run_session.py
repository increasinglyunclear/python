#!/usr/bin/env python3
"""One-command workshop session launcher.

Starts the backend app, opens a Cloudflare quick tunnel to it, captures the
(fresh, random) public URL, writes it into ws.txt / api.txt, and uploads those
two tiny files to the website over FTP — so the live site always points at this
session with no manual re-upload. Leave it running for the whole workshop; Ctrl-C
stops both the tunnel and the app.

Usage:
    python deploy/run_session.py            # start the app + tunnel + upload
    python deploy/run_session.py --no-app   # tunnel + upload only (app runs elsewhere)

Configuration lives in deploy/infomaniak.json (copy the .example.json and fill
in your Infomaniak FTP details). Nothing here touches your DNS.

Note: a quick tunnel's URL is random and changes every run — that's inherent to
free quick tunnels, not something this script can avoid. What it does avoid is
the manual ws.txt re-upload (it pushes the new URL for you each session). For a
*stable* URL, use a Cloudflare named tunnel (needs DNS on Cloudflare).
"""

from __future__ import annotations

import ftplib
import io
import json
import os
import re
import signal
import socket
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
CONFIG_PATH = os.path.join(HERE, "infomaniak.json")

LOCAL_PORT = int(os.environ.get("WW_PORT", "8000"))
TUNNEL_URL_RE = re.compile(r"https://[a-z0-9-]+\.trycloudflare\.com")


def load_config() -> dict:
    if not os.path.exists(CONFIG_PATH):
        sys.exit(
            f"Missing config: {CONFIG_PATH}\n"
            "Copy deploy/infomaniak.example.json to deploy/infomaniak.json and "
            "fill in your Infomaniak FTP details."
        )
    with open(CONFIG_PATH, "r", encoding="utf-8") as fh:
        cfg = json.load(fh)
    for required in ("host", "user", "password", "live_dir"):
        if not cfg.get(required):
            sys.exit(f"Config {CONFIG_PATH} is missing '{required}'.")
    return cfg


def start_app() -> subprocess.Popen:
    """Launch the backend app in this same Python env (its logs share this
    terminal). Returns the process so we can stop it on Ctrl-C."""
    return subprocess.Popen([sys.executable, "-m", "backend.app"], cwd=ROOT)


def wait_for_port(port: int, timeout: float = 180.0) -> bool:
    """Block until the app is accepting connections (model load can be slow on
    the first run). Returns False if it never comes up."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(1.0)
            try:
                s.connect(("127.0.0.1", port))
                return True
            except OSError:
                time.sleep(1.0)
    return False


def start_tunnel() -> subprocess.Popen:
    """Launch cloudflared and return the process (stdout is a pipe we read)."""
    try:
        return subprocess.Popen(
            ["cloudflared", "tunnel", "--url", f"http://localhost:{LOCAL_PORT}"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
        )
    except FileNotFoundError:
        sys.exit("cloudflared not found. Install it with: brew install cloudflared")


def wait_for_url(proc: subprocess.Popen, timeout: float = 40.0) -> str:
    """Read cloudflared output until the public URL appears."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        line = proc.stdout.readline()
        if not line:
            if proc.poll() is not None:
                sys.exit("cloudflared exited before printing a URL.")
            continue
        m = TUNNEL_URL_RE.search(line)
        if m:
            return m.group(0)
    sys.exit("Timed out waiting for the tunnel URL.")


def _upload_via_ftp(cfg: dict, files: list[tuple[str, str, str]]) -> None:
    """files = [(remote_dir, filename, text), ...] over FTP/FTPS (stdlib)."""
    proto = (cfg.get("protocol") or "ftps").lower()
    port = int(cfg.get("port") or 21)
    host = cfg["host"]
    if proto == "ftps":
        ftp = ftplib.FTP_TLS()
        ftp.connect(host, port, timeout=30)
        ftp.login(cfg["user"], cfg["password"])
        ftp.prot_p()  # encrypt the data channel
    else:
        ftp = ftplib.FTP()
        ftp.connect(host, port, timeout=30)
        ftp.login(cfg["user"], cfg["password"])
    try:
        for remote_dir, filename, text in files:
            ftp.cwd("/")
            for part in remote_dir.strip("/").split("/"):
                if part:
                    ftp.cwd(part)
            ftp.storbinary(f"STOR {filename}", io.BytesIO(text.encode("utf-8")))
            print(f"  \u2713 {remote_dir.rstrip('/')}/{filename}")
    finally:
        try:
            ftp.quit()
        except Exception:
            pass


def _upload_via_sftp(cfg: dict, files: list[tuple[str, str, str]]) -> None:
    """files = [(remote_dir, filename, text), ...] over SFTP (needs paramiko)."""
    try:
        import paramiko  # noqa: PLC0415 — optional dependency, only for sftp
    except ImportError:
        sys.exit(
            "SFTP needs paramiko. Install it with:  pip install paramiko\n"
            "(or set \"protocol\": \"ftps\" in deploy/infomaniak.json if your host "
            "supports FTPS)."
        )
    port = int(cfg.get("port") or 22)
    transport = paramiko.Transport((cfg["host"], port))
    transport.connect(username=cfg["user"], password=cfg["password"])
    try:
        sftp = paramiko.SFTPClient.from_transport(transport)
        for remote_dir, filename, text in files:
            path = remote_dir.rstrip("/") + "/" + filename
            with sftp.open(path, "w") as fh:
                fh.write(text)
            print(f"  \u2713 {path}")
    finally:
        transport.close()


def upload_files(cfg: dict, files: list[tuple[str, str, str]]) -> None:
    proto = (cfg.get("protocol") or "ftps").lower()
    if proto == "sftp":
        _upload_via_sftp(cfg, files)
    elif proto in ("ftp", "ftps"):
        _upload_via_ftp(cfg, files)
    else:
        sys.exit(f"Unsupported protocol '{proto}' (use 'ftps', 'ftp' or 'sftp').")


def main() -> None:
    cfg = load_config()

    # One-line launch: start the backend app too (unless --no-app, for when you
    # already run `python -m backend.app` in a separate terminal).
    run_app = "--no-app" not in sys.argv
    app_proc: subprocess.Popen | None = None
    if run_app:
        print(f"Starting the app (python -m backend.app on port {LOCAL_PORT})…", flush=True)
        app_proc = start_app()
        if not wait_for_port(LOCAL_PORT):
            print("  ✗ The app didn't start listening in time. Check its output above.")
            try:
                app_proc.terminate()
            except Exception:
                pass
            sys.exit(1)
        print("  \u2713 App is up.")

    print("Starting Cloudflare tunnel…", flush=True)
    proc = start_tunnel()
    public = wait_for_url(proc)
    wss = "wss://" + public[len("https://"):] + "/ws"

    print(f"Tunnel URL : {public}")
    print(f"WebSocket  : {wss}")

    # Write the local copies (handy for ?ws= testing and as a record).
    with open(os.path.join(ROOT, "ws.txt"), "w", encoding="utf-8") as fh:
        fh.write(wss + "\n")
    with open(os.path.join(ROOT, "api.txt"), "w", encoding="utf-8") as fh:
        fh.write(public + "\n")

    print("Uploading ws.txt / api.txt to the website…", flush=True)
    files = [(cfg["live_dir"], "ws.txt", wss + "\n")]
    if cfg.get("presentation_dir"):
        files.append((cfg["presentation_dir"], "api.txt", public + "\n"))
    try:
        upload_files(cfg, files)
        print("Upload complete. The live site now points at this session.")
    except SystemExit:
        raise
    except Exception as exc:  # noqa: BLE001 — surface any upload failure plainly
        print(f"  ✗ Upload failed: {exc}")
        print("  The tunnel is still up; you can upload ws.txt manually as a fallback.")

    print("\nTunnel is live. Keep this window open. Press Ctrl-C to end the session.\n")

    # Stream cloudflared output until interrupted, then clean up.
    def _stop(*_):
        print("\nStopping tunnel…")
        try:
            proc.terminate()
        except Exception:
            pass
        if app_proc is not None:
            print("Stopping app…")
            try:
                app_proc.terminate()
            except Exception:
                pass
        sys.exit(0)

    signal.signal(signal.SIGINT, _stop)
    signal.signal(signal.SIGTERM, _stop)
    try:
        for line in proc.stdout:
            pass  # keep draining so cloudflared doesn't block on a full pipe
    finally:
        _stop()


if __name__ == "__main__":
    main()
